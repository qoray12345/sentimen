package com.ebdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NrlApplicationTests {

	@Test
	void contextLoads() {
	}

}
